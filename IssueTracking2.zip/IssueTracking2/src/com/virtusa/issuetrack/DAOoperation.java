package com.virtusa.issuetrack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOoperation {
	  public String generateissueId() {
	        Connection con=DaoConnection.getConnection();
	        String cmd="select case when max(issue_id) is NULL then 'issue1' else max(issue_id) end issue_id from issue";
	     
	        String id="";
	        String res="";
	        try {
	            PreparedStatement pst=con.prepareStatement(cmd);            
	            ResultSet rs=pst.executeQuery();
	            
	            rs.next();
	            id=rs.getString("issue_id");
	            int sid=Integer.parseInt(id.substring(5));
	            sid++;
	           
	            if(sid>=1)
	            {
	                res="issue"+sid;
	            }
	        } catch (SQLException e) {
	                e.printStackTrace();
	        }
	        return res;
	        
	    }
	 String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	}


